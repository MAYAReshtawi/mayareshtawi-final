let walletAddress = null;

const connectWalletBtn = document.getElementById('connectWallet');
const walletAddressDisplay = document.getElementById('walletAddress');
const form = document.getElementById('web3Form');
const certTableBody = document.getElementById('certTableBody');

connectWalletBtn.addEventListener('click', async () => {
  if (window.ethereum) {
    try {
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      walletAddress = accounts[0];
      walletAddressDisplay.textContent = `Connected: ${walletAddress.substring(0,6)}...${walletAddress.slice(-4)}`;
    } catch (err) {
      alert('Wallet connection failed!');
      console.error(err);
    }
  } else {
    alert('Please install MetaMask!');
  }
});

form.addEventListener('submit', (e) => {
  e.preventDefault();
  if (!walletAddress) {
    alert('Please connect your wallet first!');
    return;
  }

  let certName = document.getElementById('certName').value;

  // Issuer
  let issuer = document.getElementById('newIssuer').value || document.getElementById('issuerSelect').value;
  // Requester
  let requester = document.getElementById('newRequester').value || document.getElementById('requesterSelect').value;
  let fee = document.getElementById('fee').value;

  // Mock submission: إضافة الشهادة للجدول
  const row = document.createElement('tr');
  row.innerHTML = `
    <td>${certName}</td>
    <td>${issuer}</td>
    <td>${requester}</td>
    <td>${walletAddress.substring(0,6)}...${walletAddress.slice(-4)}</td>
    <td>${fee}</td>
    <td>Pending ⏳</td>
  `;
  certTableBody.appendChild(row);

  // إعادة تعيين الفورم
  form.reset();
  alert('Certificate submitted to blockchain! (Mock Data)');
});
