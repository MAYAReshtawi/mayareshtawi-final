// Login Form
document.getElementById('loginForm')?.addEventListener('submit', function(e){
  e.preventDefault();
  alert('Login clicked! (Mock Data)');
  // بعدين ممكن تودينا على upload.html
  // window.location.href = 'upload.html';
});

// Register Form
document.getElementById('registerForm')?.addEventListener('submit', function(e){
  e.preventDefault();
  alert('Sign Up clicked! (Mock Data)');
  // بعدين ممكن تودينا على upload.html
  // window.location.href = 'upload.html';
});
