document.getElementById('uploadForm').addEventListener('submit', function(e){
  e.preventDefault();
  alert('Certificate uploaded! (Mock Data)');
});
