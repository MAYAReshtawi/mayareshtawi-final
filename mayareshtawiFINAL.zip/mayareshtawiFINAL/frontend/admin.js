const adminCertTable = document.getElementById('adminCertTable');

// Mock Data for demonstration
let certificates = [
  {
    certName: "Blockchain Basics",
    issuer: "University A",
    requester: "Student X",
    wallet: "0xAbc123...",
    fee: 0.01,
    status: "Pending"
  },
  {
    certName: "Web Development",
    issuer: "Company B",
    requester: "Student Y",
    wallet: "0xDef456...",
    fee: 0.02,
    status: "Verified"
  }
];

function renderTable() {
  adminCertTable.innerHTML = ""; // Clear table
  certificates.forEach((cert, index) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${cert.certName}</td>
      <td>${cert.issuer}</td>
      <td>${cert.requester}</td>
      <td>${cert.wallet}</td>
      <td>${cert.fee}</td>
      <td>${cert.status}</td>
      <td>
        ${cert.status === "Pending" ? `<button onclick="verifyCert(${index})" class="btn-primary">Verify</button>` : ""}
      </td>
    `;
    adminCertTable.appendChild(row);
  });
}

// Mock verification function
function verifyCert(index) {
  certificates[index].status = "Verified";
  renderTable();
  alert(`Certificate "${certificates[index].certName}" is now Verified ✅`);
}

// Initial render
renderTable();
