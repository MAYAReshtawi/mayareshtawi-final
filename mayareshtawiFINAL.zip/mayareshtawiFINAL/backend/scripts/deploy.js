const hre = require("hardhat");

async function main() {
  // 1️⃣ الحصول على الحساب الأول (deployer)
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying contracts with account:", deployer.address);

  // 2️⃣ الحصول على العقد من contracts/
  const CertificateContract = await hre.ethers.getContractFactory("MayarRegistry"); // غير الاسم إذا مختلف

  // 3️⃣ نشر العقد على الشبكة المحلية
  const certificate = await CertificateContract.deploy();
  await certificate.deployed(); // انتظار النشر

  // 4️⃣ طباعة عنوان العقد الجديد
  console.log("CertificateContract deployed to:", certificate.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
