const Certificate = require('../models/Certificate');
const fs = require('fs');
const path = require('path');

exports.uploadCertificate = async (req, res) => {
  try {
    const { title, issuer, owner, certificateBase64 } = req.body;

    if (!certificateBase64) {
      return res.status(400).json({ msg: 'No certificate data provided' });
    }

    // إنشاء اسم ملف فريد
    const fileName = Date.now() + '.pdf';
    const filePath = path.join(__dirname, '../uploads/', fileName);

    // تحويل Base64 إلى ملف PDF
    const base64Data = certificateBase64.replace(/^data:application\/pdf;base64,/, '');
    fs.writeFileSync(filePath, base64Data, 'base64');

    // حفظ البيانات في قاعدة البيانات
    const newCertificate = new Certificate({
      title,
      issuer,
      owner,
      fileUrl: fileName,
      verified: false,
    });

    await newCertificate.save();

    res.status(201).json({ msg: 'Certificate uploaded', certificate: newCertificate });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.verifyCertificate = async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.certificateId);
    if (!certificate) {
      return res.status(404).json({ msg: 'Certificate not found' });
    }
    res.json({ verified: certificate.verified, certificate });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};
