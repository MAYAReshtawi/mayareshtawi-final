const express = require('express');
const cors = require('cors');
require('dotenv').config();
console.log("JWT_SECRET:", process.env.JWT_SECRET);


const connectDB = require('./db'); // ربط MongoDB
connectDB(); // تشغيل الاتصال

const app = express();
app.use(cors());
app.use(express.json());
const userRoutes = require('./routes/userRoutes');
app.use('/api/users', userRoutes);
const certificateRoutes = require('./routes/certificateRoutes');
app.use('/api/certificates', certificateRoutes);



// Route تجريبي
app.get('/', (req, res) => {
  res.send('Server is running!');
});

// تشغيل السيرفر
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
