const express = require('express');
const router = express.Router();

const {
  uploadCertificate,
  verifyCertificate
} = require('../controllers/certificateController');

// راوت رفع الشهادة (JSON + Base64)
router.post('/upload', uploadCertificate);

// راوت التحقق من الشهادة
router.get('/:certificateId', verifyCertificate);

module.exports = router;
